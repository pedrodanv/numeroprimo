function calculate() {
  var number = document.getElementById('number').value;
  var primes = [];
  var sum = 0;

  for (var i = 2; i <= number; i++) {
    var isPrime = true;
    for (var j = 2; j < i; j++) {
      if (i % j == 0) {
        isPrime = false;
        break;
      }
    }
    if (isPrime) {
      primes.push(i);
      sum += i;
    }
  }

  var resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = 'Números primos: ' + primes.join(', ') + '<br>' +
                          'Suma: ' + sum;
}

function download() {
  var primes = document.getElementById('results').innerHTML;
  var file = new Blob([primes], {type: 'text/plain'});
  var a = document.createElement('a');
  var url = URL.createObjectURL(file);
  a.href = url;
  a.download = 'primes.txt';
  document.body.appendChild(a);
  a.click();
  setTimeout(function() {
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, 0);
}
